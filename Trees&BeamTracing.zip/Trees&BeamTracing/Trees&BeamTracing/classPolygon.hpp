#pragma once
#include "structPoint.hpp"

class Polygon
{
    point v[3];
    
public:
    
    Polygon(vector<int>);
};
