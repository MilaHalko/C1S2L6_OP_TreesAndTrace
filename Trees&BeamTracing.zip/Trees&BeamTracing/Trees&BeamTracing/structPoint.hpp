#pragma once
#include "libraries.hpp"

struct point
{
    int x;
    int y;
    int z;
};
