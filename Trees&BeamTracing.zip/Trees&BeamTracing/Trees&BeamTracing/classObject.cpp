#include "classObject.hpp"

void Object::readFile()
{
    ifstream fin (file);
    
    if (!fin) cout << "Error!" << endl;
    else
    {
        string str;
        while (!fin.eof())
        {
            str = "";
            getline(fin, str);
            
            if (str.find("f ") == 1)
            {
                string number = "";
                vector<int> coordinates;
                coordinates.resize(0);
                
                for (int i = 0; i < str.size(); i++)
                {
                    while (isnumber(str[i])  ||  str[i] == '.'  ||  str[i] == '-')
                    {
                        number += str[i];
                        i++;
                    }
                    
                    if (number != "")
                    {
                        coordinates.push_back(stoi(number));
                        number = "";
                    }
                }
                poligons.push_back(coordinates);
            }
        }
        fin.close();
    }
}
