#include "libraries.hpp"
#include "classObject.hpp"

int main()
{
    Object sphere;
    sphere.readFile();
    return 0;
}
